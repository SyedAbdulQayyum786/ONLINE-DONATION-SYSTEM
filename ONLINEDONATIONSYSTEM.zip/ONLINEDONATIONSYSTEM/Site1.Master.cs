﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ONLINEDONATIONSYSTEM
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //try
            //{
            //    if(Session["role"].Equals(""))
            //    {
            //        LinkButton1.Visible = true;
            //        LinkButton2.Visible = true;
            //        LinkButton4.Visible = true;
            //        LinkButton3.Visible = false;    
            //    }
            //    else if(Session["role"].Equals("userlogin"))
            //    {
            //        LinkButton1.Visible = false;
            //        LinkButton2.Visible = false;
            //        LinkButton4.Visible = false;
            //        LinkButton3.Visible = true;
            //    }
            //}
            //catch(Exception ex)
            //{

            //}
        }
    }
}